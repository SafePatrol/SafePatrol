package com.hanict.safepatrol;

/**
 * Created by answo on 2017-06-27.
 */

public class MarkItem {
    double lat;
    double lon;
    int level;

    public MarkItem(double lat, double lon, int level)
    { this.lat = lat; this.lon = lon; this.level = level; }





}
